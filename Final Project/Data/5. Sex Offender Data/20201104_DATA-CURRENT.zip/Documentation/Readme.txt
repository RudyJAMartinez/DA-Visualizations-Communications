﻿You may download the latest document from the TxDPS Crime Record Public Website.
